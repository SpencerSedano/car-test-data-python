import random

print(random.randrange(0, 100))
